# NDVI de mi parcela con Pandas

Análisis del NDVI de una parcela en Santander (Colombia) con imágenes Sentinel-2 despejadas, de diciembre de 2025 a agosto de 2026. Los datos los exporté de Google Earth Engine y los analicé con Pandas y SciPy.

![Serie de NDVI](figuras/01_serie_ndvi.png)

## Qué hace el notebook

1. **La serie:** lee las 11 fechas despejadas y el NDVI mensual de Earth Engine, y corrige el desfase de un día que aparece al exportar (UTC frente a la hora de Colombia).
2. **La tendencia mensual:** agrupa por mes con `resample`, la compara con Earth Engine y calcula el cambio mes a mes y una media móvil de 3 meses.
3. **La regresión del NDVI contra el mes:** ajusta una recta con `scipy.stats.linregress`, detecta datos atípicos con un z robusto (mediana y MAD) y compara el resultado con y sin ellos.

## Resultados

| Regresión | Pendiente por mes | R² | Valor p |
|---|---|---|---|
| Con todos los meses | −0,0108 | 0,14 | 0,37 |
| Sin julio (dato atípico) | +0,0007 | 0,01 | 0,83 |

- La parcela se mantiene estable alrededor de **NDVI 0,71**. No hay tendencia significativa.
- El **8 de julio de 2026** el NDVI cae a **0,48** (z robusto de −8,7) y se recupera en agosto (0,69). Puede ser nube o sombra sin enmascarar, o un manejo puntual. Falta revisar esa imagen en color verdadero.
- Marzo no tiene ninguna imagen despejada.

![Regresión](figuras/03_regresion_ndvi_mes.png)

## Estructura

```
ndvi_parcela.ipynb          notebook con el análisis y la explicación
data/ndvi_por_fecha.csv     NDVI promedio de la parcela por fecha despejada
data/ndvi_mensual.csv       NDVI mensual compuesto en Earth Engine
figuras/                    las 3 gráficas
ndvi_tabla_mensual.csv      tabla mensual que genera el notebook
ndvi_regresion.csv          resultados de la regresión
```

## Cómo correrlo

- **Google Colab:** abre `ndvi_parcela.ipynb`, ejecuta la primera celda y sube los dos CSV cuando te los pida.
- **En tu computador:** `pip install -r requirements.txt` y luego abre el notebook con Jupyter.

## Autor

Jahir Gualdrón Cáceres, ingeniero agrícola (Universidad Nacional de Colombia).
